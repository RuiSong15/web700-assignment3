require("dotenv").config();
 
const express = require("express");
 
const sequelize = require("./config/database");
const Product = require("./models/product");
 
const app = express();
const PORT = process.env.PORT || 3000;
 
app.use(express.json());
 
app.get("/", (req, res) => {
    res.status(200).json({
        message: "WEB700 Neon PostgreSQL Lab"
    });
});
 
app.get("/health", async (req, res) => {
    try {
        await sequelize.authenticate();
 
        res.status(200).json({
            success: true,
            message: "Connected to Neon PostgreSQL."
        });
    } catch (error) {
        console.error("Health check failed:", error.message);
 
        res.status(500).json({
            success: false,
            message: "Database connection failed."
        });
    }
});
 
app.get("/api/products", async (req, res) => {
    try {
        const products = await Product.findAll({
            order: [["id", "ASC"]]
        });
 
        res.status(200).json({
            success: true,
            count: products.length,
            data: products
        });
    } catch (error) {
        console.error("Product query failed:", error.message);
 
        res.status(500).json({
            success: false,
            message: "Unable to retrieve products."
        });
    }
});
 
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: "Route not found."
    });
});
 
async function startServer() {
    try {
        await sequelize.authenticate();
 
        console.log("Connected to Neon PostgreSQL.");
 
        app.listen(PORT, () => {
            console.log(
                `Server running at http://localhost:${PORT}`
            );
        });
    } catch (error) {
        console.error(
            "Unable to start the application:",
            error.message
        );
 
        process.exit(1);
    }
}
 
startServer();